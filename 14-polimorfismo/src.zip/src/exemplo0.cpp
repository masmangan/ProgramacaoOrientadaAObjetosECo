class Base {
public:
  void func1();
};

class Derivada : public Base {
public:
  void func2();
};
