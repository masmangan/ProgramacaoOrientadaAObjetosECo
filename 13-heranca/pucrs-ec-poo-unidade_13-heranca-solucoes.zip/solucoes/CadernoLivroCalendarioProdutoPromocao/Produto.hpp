// Produto.hpp (Roland Teodorowitsch; 30 out. 2019)

#ifndef _PRODUTO_HPP
#define _PRODUTO_HPP

#include "Promocao.hpp"

class Produto : public Promocao {
  private:
     string nome;
     double preco;
			
  public:
    Produto();
    Produto(string nome, double preco, double p);
    Produto(string nome, double preco, string promoId);
    ~Produto();
    string obtemNome();
    double calculaPreco();
};

#endif
