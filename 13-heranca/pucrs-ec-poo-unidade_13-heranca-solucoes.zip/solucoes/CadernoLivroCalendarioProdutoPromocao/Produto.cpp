// Produto.cpp (Roland Teodorowitsch; 30 out. 2019)

#include "Produto.hpp"

Produto::Produto() : Promocao() {
  this->nome = "Sem nome";
  this->preco = 0.0;
}

Produto::Produto(string nome, double preco, double promo) : Promocao(promo) {
  this->nome = nome;
  this->preco = preco;
}

Produto::Produto(string nome, double preco, string promoId) : Promocao(promoId) {
  this->nome = nome;
  this->preco = preco;
}

Produto::~Produto(){}

string Produto::obtemNome(){
  return nome;
}

double Produto::calculaPreco(){
  return preco * obtemPromocao();
}

