// Caderno.cpp (Roland Teodorowitsch; 30 out. 2019)

#include "Caderno.hpp"

Caderno::Caderno(): Produto(){
  this->paginas = 0;
}

Caderno::Caderno(string nome, double preco, double promo, int paginas): Produto(nome,preco,promo){
  this->paginas = paginas;
}

Caderno::Caderno(string nome, double preco, string promoId, int paginas): Produto(nome,preco,promoId){
  this->paginas = paginas;
}

Caderno::~Caderno(){}

int Caderno::obtemPaginas(){
  return this->paginas;
}

