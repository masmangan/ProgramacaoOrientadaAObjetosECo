// Caderno.hpp (Roland Teodorowitsch; 30 out. 2019)

#ifndef _CADERNO_HPP
#define _CADERNO_HPP

#include "Produto.hpp"

class Caderno : public Produto {
  private:
    int paginas;
			
  public:
    Caderno();
    Caderno(string nome, double preco, double promo, int paginas);
    Caderno(string nome, double preco, string promoId, int paginas);
    ~Caderno();
    int obtemPaginas();
};

#endif
