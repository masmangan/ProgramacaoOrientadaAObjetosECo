// Calendario.hpp (Roland Teodorowitsch; 30 out. 2019)

#ifndef _CALENDARIO_HPP
#define _CALENDARIO_HPP

#include "Livro.hpp"

class Calendario : public Livro {
  public:
    Calendario();
    Calendario(string nome, double preco, double promo, int paginas, int ano);
    Calendario(string nome, double preco, string promoId, int paginas, int ano);
    ~Calendario();
};

#endif
