// Promocao.cpp (Roland Teodorowitsch; 30 out. 2019)

#include"Promocao.hpp"

Promocao::Promocao(){
  promocao = 1.0;
}

Promocao::Promocao(double promo){
  promocao = promo;
}

Promocao::Promocao(string promoId){
  definePromocao(promoId);
}

Promocao::~Promocao(){}

void Promocao::definePromocao(string promoId){
  if (promoId == "liquidacao")
     promocao = 0.7;
  else if (promoId == "regular")
     promocao = 0.9;
  else
     promocao = 1.0;
}

void Promocao::definePromocao(double promo) {
  promocao = promo;
}

double Promocao::obtemPromocao(){
  return promocao;
}
