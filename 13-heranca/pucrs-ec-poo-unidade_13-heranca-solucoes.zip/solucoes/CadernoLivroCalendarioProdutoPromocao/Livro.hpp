// Livro.hpp (Roland Teodorowitsch; 30 out. 2019)

#ifndef _LIVRO_HPP
#define _LIVRO_HPP

#include "Caderno.hpp"

class Livro : public Caderno {
  private:
    int ano;

    public:
      Livro();
      Livro(string nome, double preco, double promo, int paginas, int ano);
      Livro(string nome, double preco, string promoId, int paginas, int ano);
      ~Livro();
      int obtemAno();
};

#endif
