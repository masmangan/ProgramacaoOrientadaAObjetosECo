// Livro.cpp (Roland Teodorowitsch; 30 out. 2019)

#include"Livro.hpp"

Livro::Livro() : Caderno() {
  this->ano = 0;
}

Livro::Livro(string nome, double preco, double promo, int paginas, int ano) : Caderno(nome,preco,promo,paginas) {
  this->ano = ano;
}

Livro::Livro(string nome, double preco, string promoId, int paginas, int ano) : Caderno(nome,preco,promoId,paginas) {
  this->ano = ano;
}

Livro::~Livro(){}

int Livro::obtemAno(){
  return this->ano;
}

