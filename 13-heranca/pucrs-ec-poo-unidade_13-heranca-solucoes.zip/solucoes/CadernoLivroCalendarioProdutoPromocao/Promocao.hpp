// Promocao.hpp (Roland Teodorowitsch; 30 out. 2019)

#ifndef _PROMOCAO_HPP
#define _PROMOCAO_HPP

#include <string>

using namespace std;

class Promocao {
  private:
    double promocao;
			
  public:
    Promocao();
    Promocao(double promo);
    Promocao(string promo);
    ~Promocao();
    void definePromocao(string promoId);
    void definePromocao(double promo);
    double obtemPromocao();
};

#endif
