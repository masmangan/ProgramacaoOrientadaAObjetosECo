// Calendario.cpp (Roland Teodorowitsch; 30 out. 2019)

#include "Calendario.hpp"

Calendario::Calendario() : Livro() {}

Calendario::Calendario(string nome, double preco, double promo, int ano, int paginas) : Livro(nome,preco,promo,ano,paginas) {}

Calendario::Calendario(string nome, double preco, string promoId, int ano, int paginas) : Livro(nome,preco,promoId,ano,paginas) {}

Calendario::~Calendario(){}

