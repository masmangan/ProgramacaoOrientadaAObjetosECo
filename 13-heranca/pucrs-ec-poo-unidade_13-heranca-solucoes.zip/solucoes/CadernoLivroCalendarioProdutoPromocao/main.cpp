// main.cpp (Roland Teodorowitsch; 30 out. 2019)

#include <iostream>
#include <iomanip>
#include "Caderno.hpp"
#include "Livro.hpp"
#include "Calendario.hpp"

int main () {
  Produto *produto = new Produto("Meu produto", 1.99, 1.0);
  cout << "Produto: " << produto->obtemNome() << " - " << produto->calculaPreco() << endl;
  delete produto;

  Caderno *caderno = new Caderno("Meu nome", 12.99, "normal", 50);
  cout << fixed << setprecision(2);
  cout << "Caderno " << caderno->obtemNome() << " " << caderno->obtemPaginas() << endl;
  cout << "- " << caderno->calculaPreco() << endl;
  caderno->definePromocao("liquidacao");
  cout << "- " << caderno->calculaPreco() << endl;
  caderno->definePromocao("regular");
  cout << "- " << caderno->calculaPreco() << endl;
  delete caderno;

  Livro livro("Vinte Mil Leguas Submarinas",35.20,0.8,504,2014);
  cout << "Livro - " << livro.obtemAno() << ": " << livro.calculaPreco() << endl;
  
  Calendario calendario("2019",15.00,1.0,12,2019);
  cout << "Calendario - " << calendario.obtemAno() << ": " << calendario.calculaPreco() << endl;
  
  return 0;
}
