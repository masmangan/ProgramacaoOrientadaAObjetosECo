#include<iostream>
#define SIZE 4

using namespace std;

int main () {
	int m[SIZE][SIZE];
	int l, c, menor, pos;
	
	for(l=0;l<SIZE;l++)
		for(c=0;c<SIZE;c++)
			cin >> m[l][c];
	
	menor = m[l][c];
	pos = l;
	for(l=0;l<SIZE;l++){
		for(c=0;c<SIZE;c++){
			if (menor > m[l][c]){
				menor = m[l][c];
				pos = l;
			}
		}
	}
	
	cout << "A linha que contem o menor numero eh: " << pos << endl;
	return 0;
}