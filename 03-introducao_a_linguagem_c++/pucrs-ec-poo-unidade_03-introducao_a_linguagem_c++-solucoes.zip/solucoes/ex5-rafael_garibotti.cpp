//http://www.cplusplus.com/reference/string/string/compare/

#include<iostream>
#include<string>

using namespace std;

int main () {
	string n1, n2;
	
	cout << "Digite o 1 nome: ";
	cin >> n1;
	cout << "Digite o 2 nome: ";
	cin >> n2;
	
	if(n2.compare(n1) > 0)
		cout << n1 << endl << n2 << endl;
	else
		cout << n2 << endl << n1 << endl;

	return 0;
}