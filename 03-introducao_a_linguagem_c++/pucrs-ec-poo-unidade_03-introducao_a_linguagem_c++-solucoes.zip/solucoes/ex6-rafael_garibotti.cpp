#include<iostream>
#include<iomanip>
#define SIZE 3

using namespace std;

void funcao_modulo (int m[SIZE][SIZE]){
	int l, c;
	for(l=0;l<SIZE;l++)
		for(c=0;c<SIZE;c++)
			if(m[l][c] < 0)
			  m[l][c] = -1 * m[l][c];
}

int main () {
	int m[SIZE][SIZE];
	int l, c, menor, pos;
	
	for(l=0;l<SIZE;l++)
		for(c=0;c<SIZE;c++)
			cin >> m[l][c];
	
	funcao_modulo(m);

	for(l=0;l<SIZE;l++){
		for(c=0;c<SIZE;c++){
			cout << setw(4) << m[l][c];
		}
		cout << endl;
	}
	return 0;
}