#include<iostream>

using namespace std;

int main () {
	float n1, n2, n3, me, ma;
	
	cout << "Digite a nota 1: ";
	cin >> n1;
	cout << "Digite a nota 2: ";
	cin >> n2;
	cout << "Digite a nota 3: ";
	cin >> n3;
	cout << "Digite a media dos exercicios: ";
	cin >> me;
	
	ma = (n1 + n2*2 + n3*3 + me)/7;
	
	if(ma > 9)
		cout << "Conceito A" << endl;
	else if (ma > 7.5)
		cout << "Conceito B" << endl;
	else if (ma > 6)
		cout << "Conceito C" << endl;
	else if (ma > 4)
		cout << "Conceito D" << endl;
	else
		cout << "Conceito E" << endl;

	return 0;
}