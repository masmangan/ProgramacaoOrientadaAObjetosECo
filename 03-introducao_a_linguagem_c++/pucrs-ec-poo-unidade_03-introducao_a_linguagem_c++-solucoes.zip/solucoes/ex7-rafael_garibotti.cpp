#include<iostream>
#include<string>

using namespace std;

void remove_str(char str[100], int pos){
  int i;
	for(i = pos; i < 98; i++)
		str[i] = str[i+1];
}

int main () {
	char str[100];
  int pos;

	cout << "Digite a string: ";
  cin.getline(str, 100);
	cout << "Digite a posicao que sera retirada: ";
	cin >> pos;
	
	remove_str(str, pos);
	
  cout << str << endl;
	return 0;
}