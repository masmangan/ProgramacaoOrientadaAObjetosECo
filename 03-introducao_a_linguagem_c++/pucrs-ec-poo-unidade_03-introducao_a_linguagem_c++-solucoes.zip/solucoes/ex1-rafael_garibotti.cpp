#include<iostream>
#include<string>
#include<cstdlib>
#include<ctime>

using namespace std;

struct DATA_NSC{
	int dia;
  int mes;
	int ano;
};

struct PESSOA{
	string nome;
  float altura;
	struct DATA_NSC nsc;
};

void inserir_nome (struct PESSOA p[10], int i){
	cout << "Digite o nome: ";
	cin  >> p[i].nome;
	cout << "Digite a altura: ";
	cin  >> p[i].altura;
	p[i].nsc.dia = rand() % 31 + 1;
	p[i].nsc.mes = rand() % 12 + 1;
	p[i].nsc.ano = 2016 - rand() % 100;
}

void listar_nomes (struct PESSOA p[10], int num){
	int i;
	for(i=0; i<num; i++)
	  cout << "Nome: " << p[i].nome << " Altura: " << p[i].altura << endl;
	cout << endl;
}

void listar_nomes_data (struct PESSOA p[10], int num, struct DATA_NSC data){
	int i;
	for(i=0; i<num; i++){
		if ((p[i].nsc.ano < data.ano) ||
	      ((p[i].nsc.ano == data.ano) && (p[i].nsc.mes < data.mes)) ||
			  ((p[i].nsc.ano == data.ano) && (p[i].nsc.mes == data.mes) &&  (p[i].nsc.dia < data.dia)))
		  cout << "Nome: " << p[i].nome << " Altura: " << p[i].altura << endl;
	}
	cout << endl;
}

int main () {
	int op, num = 0;
	struct PESSOA p[10];
	struct DATA_NSC data;
	srand(time(NULL));
	
	do{
    cout << "-----------------------------------------------" << endl;
	  cout << "(1) inserir um nome" << endl;
	  cout << "(2) listar nomes e alturas" << endl;
	  cout << "(3) listas nomes que nasceram antes de uma data" << endl;
	  cout << "(4) sair do programa" << endl;
	  cout << "-----------------------------------------------" << endl;
    cout << "Escolha uma opcao: ";
	  cin >> op;
		if(op == 1){
		  inserir_nome(p, num);
			if (num < 10)
				num++;
		}
		if(op == 2)
			  listar_nomes(p, num);
		if(op == 3){
			cout << "Digite o dia de referencia: ";
			cin >> data.dia;
			cout << "Digite o mes de referencia: ";
			cin >> data.mes;
			cout << "Digite o ano de referencia: ";
			cin >> data.ano;
		  listar_nomes_data(p, num, data);
		}
	} while(op!=4);
	return 0;
}