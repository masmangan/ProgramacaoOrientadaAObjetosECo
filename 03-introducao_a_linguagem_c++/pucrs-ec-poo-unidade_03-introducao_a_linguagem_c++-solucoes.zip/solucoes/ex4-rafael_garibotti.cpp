#include<iostream>

using namespace std;

int main () {
	int n, i, j;
	
	cout << "Digite um numero impar: ";
	cin >> n;
	
	for(i=1;i<=(n/2)+1;i++){
		for(j=1;j<=n;j++){
			if((i>j) || (j>n+1-i))
				cout << " ";
			else
				cout << j;
		}
		cout << endl;
	}
	
	return 0;
}